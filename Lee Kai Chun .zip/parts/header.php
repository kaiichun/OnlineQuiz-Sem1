<!DOCTYPE html>
<html>
    <head>
        <title>Online Quiz System</title>
        <link href="/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="/bootstrap/css/bootstrap-icons.min.css" rel="stylesheet">
        <style type="text/css">
            body { background: #f1f1f1; }
        </style>
    </head>
    <body>